using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EventManager : MonoBehaviour
{
    /*public GameObject Ui;
    public Button Por;

   /* private void Start()
    {
        Ui.SetActive(false);
    }

    private void Update()
    {
        if (Ui.activeSelf == false) //�ν�����â ���̴��� üũ
            Por.onClick.AddListener(show);

        else
            Por.onClick.AddListener(exit);

    }

    void show()
    {
        Ui.SetActive(true);
       // Invoke("Hide", 3); //3�� �� �����. 
    }

    void exit()
    {
        Ui.SetActive(false);
    }
 void Hide() { Ui.SetActive(false); }


    */
}